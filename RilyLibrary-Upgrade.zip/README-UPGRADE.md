# RilyLibrary - Versi Profesional

Website perpustakaan digital modern dengan tema maroon & cream.

## Fitur Baru yang Ditambahkan

- Desain modern profesional (maroon & cream)
- Navbar sticky
- Book card bisa diklik → modal detail
- Search + filter kategori + sorting (judul & tahun)
- Tombol favorit (disimpan di localStorage)
- Semua cover selalu terlihat (fallback judul buku)
- Bubble chat dengan panel di dalam web
- Responsif penuh
- Status buku (Tersedia / Dipinjam) dengan badge warna

## Cara Pakai

1. Ganti file `index.html`, `style.css`, dan `script.js` di repo kamu dengan file yang ada di sini.
2. Pastikan folder `data/books.json` tetap ada.
3. Push ke GitHub Pages.
4. Selesai.

## Catatan

- Chat panel saat ini menggunakan balasan otomatis sederhana.
- Favorit tersimpan di browser user (localStorage).
- Cover yang gagal load akan menampilkan judul buku di background maroon.
